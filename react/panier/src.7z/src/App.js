import React, { Component } from 'react';
import Menu from './menu.js';
import Data from './state.js';
import Titre from './cours react.js';
import logo from './logo.svg';
import './App.css';

class App extends Component {
    constructor(){
        super();
        this.state = {Header : "je suis un header"};
    }


  render() {
    return (
      <div className="App">
          <h1> Test </h1>
          <h3>{this.props.dataProps}</h3>
          <h3>{this.props.dataProps2}</h3>
          <h3>{this.props.contentProps}</h3>
          <Header headerProps={this.state.Header}/>


        <header className="App-header">
          <Titre/>
          <Menu/>
          <Data/>
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <Login/>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>


    );
  }
}

export default App;

class Login extends Component {
    render() {
        return (
            <React.Fragment>
            <form>

            <div className="form-group">
            <label htmlFor="inputEmail1">Email</label>
            <input type="email" className="form-control" id="inputEmail1" aria-describedby="emailHelp" placeholder="Enter email"/>
            <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div className="form-group">
            <label htmlFor="inputPassword1">Password</label>
            <input type="password" className="form-control" id="inputPassword1" placeholder="Password"/>
            </div>
            <div className="form-group form-check">
            <input type="checkbox" className="form-check-input" id="exampleCheck1"/>
            <label className="form-check-label" htmlFor="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>

            </form>
            </React.Fragment>
        )
    }
}
// les balises dans le return <React.Fragment> servent à retirer les balises <div> inutiles que l'ont doit absolument mettre dans les return(...) de nos render() pour que
// le code soit lu et interprété par le navigateur

//on peut définir les props par défaut à l'intérieur du composant.
//ceci est une autre méthode de donnée des propriétées à ma classe App. La premiere méthode était directement dans son appel dans le document index.js

App.defaultProps ={
    contentProps :"je suis le contenu par défaut de APP"
}

class Header extends Component {
    render(){
        return(
            <h2> {this.props.headerProps}</h2>
        )
    }
}